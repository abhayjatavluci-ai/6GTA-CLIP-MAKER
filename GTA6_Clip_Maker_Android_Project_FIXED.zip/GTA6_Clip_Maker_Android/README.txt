GTA 6 CLIP MAKER — Android source project (Version 1)

WHAT THIS VERSION DOES
- Android app project for Android Studio.
- Lets the user select a video stored on the phone.
- Samples frames and ranks moments with larger visual changes.
- Exports up to 10 short MP4 segments.
- Creates a text file with a suggested title and hashtags.

HONEST LIMITATIONS
- This is an early MVP, not a finished AI editor.
- It detects visual changes only; it does not truly understand GTA events such as kills, funny moments, chases, or crashes.
- This version does NOT yet burn captions, add music/SFX, or crop to 9:16. Those need the next development pass and proper testing on real Android devices.
- The app does not download YouTube videos. Use a local video file you own or have permission to edit.
- Exports are stored in the app's private external files folder. Use Android Studio/device file tools to retrieve them in this MVP.

BUILD APK
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if prompted.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK appears under app/build/outputs/apk/debug/.

No paid API is used. Android Studio and the project source are free. This ZIP is source code, not an already-built APK.
